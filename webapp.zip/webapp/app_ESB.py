from flask import Flask, render_template, request, session, redirect

import more_itertools

import altair as alt
import pandas as pd


alt.data_transformers.disable_max_rows()


app = Flask(__name__)

# These are read-only GLOBAL variables.
Councils_Data = pd.read_csv("data/Visualization_Data.csv")  
Counties_Cities= sorted(Councils_Data.Councils_County_City.unique())  



Councils_Data["Year_Month"] = pd.to_datetime(Councils_Data["Year_Month"])

print(Councils_Data.shape)  


def produce_table(Counties_Cities, size=5):
    output = "<table>"
    for chunk in more_itertools.chunked(Counties_Cities, size):
        
        output += "<tr>"
        for s in chunk:
            output += f"<td><input type='checkbox' name='{s}' value='{s}'>{s}</td>"
        output += "</tr>"
    output += "</table>"
    return output


@app.route("/")
@app.route("/Counties_Cities")
def show_symbols():
    the_table = produce_table(Counties_Cities, 12)
    return render_template("checks.html", data=the_table)


@app.route("/processchecks", methods=["POST"])
def process_checks():
    
    session["selection"] = list(request.form.keys())
    
    return redirect("/showdata")


@app.route("/showdata")
def display_session():
    # Extract only that data which is included in the list of selected stocks.
    df = pd.concat(
        Councils_Data[Councils_Data.Councils_County_City == sel_county] for sel_county in session["selection"]
    )

    

    # Let's produce the "untidy" dataframe from the filtered data using the selected list of stocks.
    stats = pd.concat(
        (
            df[df["Councils_County_City"] == sel_county]
            .describe()
            
            for sel_county in session["selection"]
        ),
        axis="columns",
    )
    table = stats.to_html()
    return render_template("untidy.html", data=table)


@app.route("/visual")
def display_the_plot():
    
    
    Councils_Data['Year'] = Councils_Data['Year_Month'].dt.year
    Councils_Data['Month'] = Councils_Data['Year_Month'].dt.month
    Data_2007 = Councils_Data[Councils_Data['Year'] == 2007]
    
    Data_2007_plot = pd.concat(Data_2007[Data_2007.Councils_County_City == sel_county] for sel_county in session["selection"])
    ## print(df.shape)
    ## print(session["selection"])
    County_Plot = (alt.Chart(Data_2007_plot).mark_bar().encode(
    x=alt.X(
        "Month", 
        title="Months in 2007",
    ),
    y=alt.Y(
        "No_Households",
        title="Connections Established",
    ),
    color="Councils_County_City",
    column=alt.Column('Councils_County_City', header=alt.Header(title=None, labelOrient='bottom'))
    ).configure_view(
    stroke='transparent'
    )
    )

    County_Plot.save("templates/plot.html")
    return render_template("plot.html")


app.secret_key = ".v/vndfl/n/dlfkn/ldfkn/ldkngLKN"


if __name__ == "__main__":
    app.run(debug=True)
